function [ xe ] = Forw_Kin_Final( q )
a = zeros(7,1);
d = [.34 0 .4 0 .4 0 .126]';
alpha = [-pi/2 pi/2 pi/2 -pi/2 -pi/2 pi/2 0]';
T_total = eye(4);
for i =1:7
    T = [cos(q(i)) -sin(q(i))*cos(alpha(i)) sin(q(i))*sin(alpha(i)) a(i)*cos(q(i));...
         sin(q(i)) cos(q(i))*cos(alpha(i)) -cos(q(i))*sin(alpha(i)) a(i)*sin(q(i));...
         0 sin(alpha(i)) cos(alpha(i)) d(i); 0 0 0 1];
     T_total = T_total*T;
end

xe = zeros(6,1);
xe(1:3) = T_total(1:3,4);

phi = atan2(T_total(2,3),T_total(1,3));
theta = atan2(sqrt(T_total(1,3)^2 + T_total(2,3)^2),T_total(3,3));
psi = atan2(T_total(3,2),-T_total(3,1));
xe(4) = phi;
xe(5) = theta;
xe(6) = psi;
end

