clear all
close all
clc

q1 = [58.2686 75.3224 11.7968 45.9029 -22.1081 -31.2831 -42.3712];
q1 = deg2rad(q1);
qc = [97.31 -4.70 162.57 103.53 -1.96 -62.33 113.31];
qc = deg2rad(qc);
q = zeros(2000,7);
qdot = zeros(2000,7);
freq = .005;
a = zeros(1,7);
d = [.34 0 .4 0 .4 0 .126];
alpha = [-pi/2 pi/2 pi/2 -pi/2 -pi/2 pi/2 0];

q_lim = deg2rad([170 120 170 120 170 120 175]);
q_dot_lim = deg2rad([98 98 100 130 140 180 180]);

TOE_qc = T_arm_calc(a,d,alpha,qc);

a_c = .0662;
d_c = .025+.0181;
theta_c = -pi/2;
alpha_c = 0;
TEC = [cos(theta_c) -sin(theta_c)*cos(alpha_c) sin(theta_c)*sin(alpha_c) a_c*cos(theta_c);
    sin(theta_c) cos(theta_c)*cos(alpha_c) -cos(theta_c)*sin(alpha_c) a_c*sin(theta_c);
    0 sin(alpha_c) cos(alpha_c) d_c;
    0 0 0 1];

trans_mat = [-0.205780720039398 -0.109793029482687 0.56125211550912];
rpy = deg2rad([-1.9587388578232 -17.3967534123935 174.1750404305652]);
RCA = eul2rotm(rpy,'ZYX');
TCA = [RCA,trans_mat';0 0 0 1];

TAT = [1 0 0 .103975; 0 1 0 -.103975; 0 0 1 0; 0 0 0 1];

TOT = TOE_qc*TEC*TCA*TAT;

TES = [0 -1 0 0 ; -1 0 0 .0455; 0 0 -1 .060; 0 0 0 1];

TOE_qf = TOT*inv(TES);

T_final = TOE_qf;
xf = zeros(1,6);
xf(1:3) = T_final(1:3,4);
phi = atan2(T_final(2,3),T_final(1,3));
theta = atan2(sqrt(T_final(1,3)^2 + T_final(2,3)^2),T_final(3,3));
psi = atan2(T_final(3,2),-T_final(3,1));
xf(4) = phi;
xf(5) = theta;
xf(6) = psi;

q_guess = [-2 -2 -2 -2 1 1 1];
%rad2deg(q_guess)

xe = Forw_Kin_Final(q_guess');
e = xf' - xe;
q_find = q_guess';
K = .1;
iter = 0;
table_check = zeros(2000,1);

while (max(abs(e)) > 0.00000001)
    Ja = Ja_Final(q_find);
    qdot_find = K*(Ja'*(Ja*Ja')^-1)*e;
    q_find = q_find + qdot_find;
    xe = Forw_Kin_Final(q_find);
    e = xf' - xe;
    iter = iter +1;
end
iter;
qf = q_find';
%rad2deg(qf);

a0 = q1;
a1 = zeros(1,7);
a2 = (-3*(q1-qf))/(8^2);
a3 = (2*(q1-qf))/(8^3);
t = 0:freq:9.995;

qcheck = zeros(2000,7);
qdotcheck = zeros(2000,7);

for i = 1:1600
    q(i,:) = a3*t(i)^3+a2*t(i)^2+a1*t(i)+a0;
    qdot(i,:) = 3*a3*t(i)^2+2*a2*t(i)+a1;
    for j = 1:7
        if abs(q(i,j)) > q_lim(j)
            qcheck(i,j) = 1;
        end
        if abs(qdot(i,j)) > q_dot_lim(j)
            qdotcheck(i,j) = 1;
        end
    end
    xe_traj = Forw_Kin_Final(q(i,:));
    if xe_traj(1)<.33 & xe_traj(2)<.33 & xe_traj(3)<0
        table_check(i) = 1;
    end
end

for i = 1:400
    q(1600+i,:) = q(1600,:);
end

figure
plot(t, qcheck, 'ro' , t, qdotcheck, 'b-');
title('Do q or qdot exceed limits?');
xlabel('Time');
legend('q', 'qdot');
figure
plot(t,table_check,'ro');
title('Do robot hit the table?');
xlabel('Time');

fileID = fopen('Ludwin_Connor_Robot_Arm_trajectory.txt','w');
for i = 1:size(q,1)
    fprintf(fileID, '%0.8f %0.8f %0.8f %0.8f %0.8f %0.8f %0.8f\n', q(i,:));
end

fclose(fileID)
