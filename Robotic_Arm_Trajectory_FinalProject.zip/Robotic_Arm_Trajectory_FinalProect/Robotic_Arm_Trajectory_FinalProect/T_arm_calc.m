function T_current = T_arm_calc(a, d, alpha, q);
for i = 1:7
    T{i} = [cos(q(i)) -sin(q(i))*cos(alpha(i)) sin(q(i))*sin(alpha(i)) a(i)*cos(q(i));
    sin(q(i)) cos(q(i))*cos(alpha(i)) -cos(q(i))*sin(alpha(i)) a(i)*sin(q(i));
    0 sin(alpha(i)) cos(alpha(i)) d(i);
    0 0 0 1];
end

T_current = T{1}*T{2}*T{3}*T{4}*T{5}*T{6}*T{7};